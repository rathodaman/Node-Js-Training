module.exports = {
    database: {
        "username": "<username>>",
        "password": "<password>>",
        "database": '<database>', // set name of centaral database
        "host": "127.0.0.1",
        "port": "27017",
    }
}